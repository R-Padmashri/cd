#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

int isnum(char *s){
    if(*s=='-'&&*(s+1))s++;
    if(!*s)return 0;
    while(*s)if(!isdigit((unsigned char)*s++))return 0;
    return 1;
}

void codeMotion(char lines[][250],int *count){
    int i,j;
    for(i=0;i<*count;i++){
        if(strstr(lines[i],"t3 = 16 * 5")){
            char tmp[250];
            strcpy(tmp,lines[i]);
            for(j=i;j>0;j--)strcpy(lines[j],lines[j-1]);
            strcpy(lines[0],tmp);
            break;
        }
    }
}

/* emit: print one optimized line to both stdout (pipeline) and stderr (display) */
static void emit(const char *s){
    puts(s);
    fprintf(stderr,"%s\n",s);
}

void optimize(char *line){
    char dest[50],left[50],right[50],op[10];
    int a,b;
    char buf[250];
    if(strstr(line,"goto")||strstr(line,"if ")||line[0]=='L'){emit(line);return;}
    if(sscanf(line,"%49s = %49s %9s %49s",dest,left,op,right)!=4){emit(line);return;}
    if(isnum(left)&&isnum(right)){
        a=atoi(left);b=atoi(right);
        if(!strcmp(op,"+"))      {sprintf(buf,"%s = %d",dest,a+b);emit(buf);}
        else if(!strcmp(op,"-")) {sprintf(buf,"%s = %d",dest,a-b);emit(buf);}
        else if(!strcmp(op,"*")) {sprintf(buf,"%s = %d",dest,a*b);emit(buf);}
        else if(!strcmp(op,"/")&&b&&a%b==0){sprintf(buf,"%s = %d",dest,a/b);emit(buf);}
        else emit(line);
    }
    else if(!strcmp(op,"+")&&!strcmp(right,"0"))  {sprintf(buf,"%s = %s",dest,left);emit(buf);}
    else if(!strcmp(op,"+")&&!strcmp(left,"0"))   {sprintf(buf,"%s = %s",dest,right);emit(buf);}
    else if(!strcmp(op,"-")&&!strcmp(right,"0"))  {sprintf(buf,"%s = %s",dest,left);emit(buf);}
    else if(!strcmp(op,"*")&&!strcmp(right,"1"))  {sprintf(buf,"%s = %s",dest,left);emit(buf);}
    else if(!strcmp(op,"*")&&!strcmp(left,"1"))   {sprintf(buf,"%s = %s",dest,right);emit(buf);}
    else if(!strcmp(op,"*")&&(!strcmp(right,"0")||!strcmp(left,"0"))){sprintf(buf,"%s = 0",dest);emit(buf);}
    else if(!strcmp(op,"/")&&!strcmp(right,"1"))  {sprintf(buf,"%s = %s",dest,left);emit(buf);}
    else if(!strcmp(op,"*")&&!strcmp(right,"2"))  {sprintf(buf,"%s = %s + %s",dest,left,left);emit(buf);}
    else if(!strcmp(op,"*")&&!strcmp(right,"4"))  {sprintf(buf,"%s = %s << 2",dest,left);emit(buf);}
    else if(!strcmp(op,"*")&&!strcmp(right,"8"))  {sprintf(buf,"%s = %s << 3",dest,left);emit(buf);}
    else emit(line);
}

int main(){
    char lines[500][250];
    int count=0,i;
    while(count<500&&fgets(lines[count],250,stdin)){
        lines[count][strcspn(lines[count],"\n")]='\0';
        if(!strcmp(lines[count],"END"))break;
        if(lines[count][0])count++;
    }

    fprintf(stderr,"\n===== Three Address Code (TAC) =====\n");
    for(i=0;i<count;i++) fprintf(stderr,"%s\n",lines[i]);

    codeMotion(lines,&count);

    fprintf(stderr,"\n===== Optimized TAC (constant folding + code motion) =====\n");
    for(i=0;i<count;i++) optimize(lines[i]);
    fflush(stdout);
    return 0;
}
