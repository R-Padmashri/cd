#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int isnum(char *s)
{
    if (*s == '-')s++;
    if (*s == '\0')return 0;
    while (*s){
        if (!isdigit(*s))return 0;
        s++;
    }
    return 1;
}

void emit(char *line)
{
    printf("%s\n", line);
    fprintf(stderr, "%s\n", line);
}

void optimize(char *line)
{
    char dest[20], left[20], op[5], right[20];
    int a, b;
    char result[100];
    if (line[0] == 'L' || strstr(line, "goto") || strstr(line, "if")){emit(line); return; }
    if (sscanf(line, "%s = %s %s %s",dest, left, op, right) != 4){emit(line);return;}
    if (isnum(left) && isnum(right))
    {
        a = atoi(left);
        b = atoi(right);
        if (!strcmp(op, "+"))sprintf(result, "%s = %d", dest, a + b);
        else if (!strcmp(op, "-"))sprintf(result, "%s = %d", dest, a - b);
        else if (!strcmp(op, "*"))sprintf(result, "%s = %d", dest, a * b);
        else if (!strcmp(op, "/") && b != 0)sprintf(result, "%s = %d", dest, a / b);
        else{emit(line);return;}
        emit(result);
        return;
    }

    if (!strcmp(op, "+") && !strcmp(right, "0"))sprintf(result, "%s = %s", dest, left);
    else if (!strcmp(op, "+") && !strcmp(left, "0"))sprintf(result, "%s = %s", dest, right);
    else if (!strcmp(op, "-") && !strcmp(right, "0"))sprintf(result, "%s = %s", dest, left);
    else if (!strcmp(op, "*") && !strcmp(right, "1"))sprintf(result, "%s = %s", dest, left);
    else if (!strcmp(op, "*") && !strcmp(left, "1"))sprintf(result, "%s = %s", dest, right);
    else if (!strcmp(op, "*") &&(!strcmp(left, "0") || !strcmp(right, "0")))sprintf(result, "%s = 0", dest);
    else if (!strcmp(op, "/") && !strcmp(right, "1"))sprintf(result, "%s = %s", dest, left);
    else if (!strcmp(op, "*") && !strcmp(right, "2"))sprintf(result, "%s = %s + %s", dest, left, left);
    else{emit(line);return;}

    emit(result);
}

void codeMotion(char lines[][100], int *n)
{
    int i, j;
    for (i = 0; i < *n; i++)
    {
        char dest[20], left[20], op[5], right[20];
        if (sscanf(lines[i], "%s = %s %s %s",dest, left, op, right) == 4)
        {
            if (isnum(left) && isnum(right)){
                char temp[100];
                strcpy(temp, lines[i]);
                for (j = i; j > 0; j--)strcpy(lines[j], lines[j - 1]);
                strcpy(lines[0], temp);
            }
        }
    }
}

int main()
{
    char lines[100][100];
    int n = 0;
    int i;

    while (n < 100 && fgets(lines[n], 100, stdin))
    {
        lines[n][strcspn(lines[n], "\n")] = '\0';
        if (strcmp(lines[n], "END") == 0)break;
        if (strlen(lines[n]) > 0)n++;
    }

    fprintf(stderr, "\n===== ORIGINAL TAC =====\n");
    for (i = 0; i < n; i++)fprintf(stderr, "%s\n", lines[i]);
    codeMotion(lines, &n);
    fprintf(stderr, "\n===== OPTIMIZED TAC =====\n");
    for (i = 0; i < n; i++)optimize(lines[i]);
    return 0;
}